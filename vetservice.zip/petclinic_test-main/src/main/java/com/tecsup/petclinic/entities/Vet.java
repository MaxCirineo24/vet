package com.tecsup.petclinic.entities;

import lombok.Data;
import org.springframework.boot.autoconfigure.domain.EntityScan;

import javax.persistence.*;

@EntityScan("com.tecsup.petclinic.entities")
@Entity(name = "vets")
@Data
public class Vet{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	// Constructor por defecto necesario para JPA
	public Vet() {
	}


	public Vet(String firstName, String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
	}

	// Getters y setters generados automáticamente por Lombok
}
