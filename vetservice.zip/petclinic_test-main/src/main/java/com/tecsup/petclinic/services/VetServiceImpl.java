package com.tecsup.petclinic.services;

import com.tecsup.petclinic.entities.Pet;
import com.tecsup.petclinic.exception.PetNotFoundException;
import com.tecsup.petclinic.repositories.PetRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * 
 * @author jgomezm
 *
 */
@Service
@Slf4j
public class VetServiceImpl implements VetService {


	PetRepository petRepository;

	public VetServiceImpl(PetRepository petRepository) {
		this.petRepository = petRepository;
	}


	/**
	 * @param pet
	 * @return
	 */
	@Override
	public Pet create(Pet pet) {
		return petRepository.save(pet);
	}

	@Override
	public List<Pet> findAll() {
		return null;
	}

	/**
	 *
	 * @param pet
	 * @return
	 */

}